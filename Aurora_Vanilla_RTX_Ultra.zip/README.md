# Aurora Vanilla RTX Ultra

**Una edición comunitaria masivamente mejorada de Super Duper Vanilla.**

Esta versión toma la base sólida de Super Duper Vanilla y la lleva a otro nivel: colores más ricos y cinematográficos, cielo nocturno con auroras sutiles, mejores reflejos, nubes de mayor calidad, iluminación volumétrica más presente, agua más profunda y un tone-mapping rediseñado que preserva detalles en las altas luces.

> Edición no oficial. No está afiliada ni respaldada por Eldeston / FlameRender Studios.

---

## Mejoras principales (Ultra)

### Imagen y color
- Tone-mapping rediseñado con mejor preservación de highlights y midtones más ricos.
- Contraste y saturación refinados (sin llegar a lo oversaturated).
- Auto-exposure activado por defecto para adaptabilidad dinámica.
- Bloom más natural y lens flare más contenido.
- Blocklight más cálido y agradable.

### Cielo y atmósfera
- **Auroras sutiles** en el cielo nocturno (efecto animado y performante, se atenúa con lluvia).
- Más pasos de muestreo en nubes (skybox + volumétricas).
- Volumetric lighting más intenso y visible.
- Mejor integración de nubes dobles y dinámicas.

### Reflejos y calidad
- Raytracer de reflejos con más pasos (32 + 4 binary steps) → reflejos más limpios y estables.
- Agua con normales más definidas y color más profundo.
- SSAO, sombras suaves y filtros de calidad mantenidos/optimizados.

### Rendimiento
- Sigue siendo un shader "vanilla-friendly" y relativamente ligero.
- Las subidas de calidad se concentran en opciones que se notan visualmente sin destrozar el FPS en GPUs modernas (RTX / equivalentes).
- Pensado especialmente para Iris + GPUs de media-alta gama.

---

## Cambios técnicos destacados

| Área              | Antes (base)     | Aurora Ultra          |
|-------------------|------------------|-----------------------|
| Raytracer steps   | 24               | **32**                |
| Binary refinement | 2                | **4**                 |
| Volumetric clouds | 16 steps         | **32**                |
| Skybox clouds     | 24 steps         | **48**                |
| Bloom strength    | 0.65             | 0.72 (más natural)    |
| Lens flare        | 0.70             | 0.55 (más sutil)      |
| Contraste         | 1.05             | **1.12**              |
| Saturación        | 1.08             | **1.15**              |
| White point       | 2.0              | **2.4**               |
| Shoulder          | 0.15             | **0.22**              |
| Auto Exposure     | Off              | **On**                |
| Auroras nocturnas | No               | **Sí (nuevo)**        |

---

## Instalación

1. Usa **Iris** (recomendado) o OptiFine (soporte parcial).
2. Coloca el zip en la carpeta `shaderpacks`.
3. Activa el shader desde el menú de Iris/OptiFine.
4. ¡Disfruta!

Recomendado: Iris 1.6.10+ y Minecraft 1.18.2+.

---

## Créditos

- **Base original**: Super Duper Vanilla por [Eldeston](https://github.com/Eldeston) / FlameRender Studios.
- **Edición Aurora Vanilla RTX Ultra**: mejoras de imagen, auroras, tuning de calidad y presentación.
- Licencia original de FlameRender Studios se mantiene (ver LICENSE).

Si te gusta esta edición, considera apoyar al autor original de Super Duper Vanilla.

---

## Notas

- Las auroras son sutiles a propósito: no quieren dominar la escena, solo añadir magia al cielo nocturno.
- Si prefieres un look más cercano al original, puedes bajar los pasos de raytracing/nubes y desactivar las auroras (comentando el bloque correspondiente en `skyRender.glsl`).
- Feedback bienvenido.

**¡Disfruta de un Minecraft mucho más hermoso!**
