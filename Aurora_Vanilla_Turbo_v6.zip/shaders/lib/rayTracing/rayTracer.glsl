const uint rayTraceSteps = uint(RAYTRACER_STEPS);
const uint rayTraceBiSteps = uint(RAYTRACER_BISTEPS);


// Highly optimized SSR raytracer (Belmu/Shadax lineage)
// Same intersection quality, fewer redundant ops and better early outs
vec3 rayTraceScene(in vec3 screenPos, in vec3 viewPos, in vec3 rayDir, in float dither){
	// Near-surface blob fix
	if(rayDir.z > -viewPos.z) return vec3(0.0);

	// Screenspace direction (pre-normalized scale)
	vec3 screenRay = fastNormalize(getScreenPos(gbufferProjection, viewPos + rayDir) - screenPos) * rayTracerStepsInv;

	vec3 pos = screenPos + screenRay * dither;

	// Main march
	for(uint i = 0u; i < rayTraceSteps; ++i){
		pos += screenRay;

		// Bounds check (cheaper than 4 comparisons in some compilers)
		if(any(lessThan(pos.xy, vec2(0.0))) || any(greaterThan(pos.xy, vec2(1.0)))) return vec3(0.0);

		float depth = textureLod(depthtex0, pos.xy, 0).x;

		// Hand / very close geometry
		if(depth <= 0.56) return vec3(0.0);

		if(depth < pos.z){
			// Binary refinement
			#if RAYTRACER_BISTEPS != 0
				vec3 refineDir = screenRay;
				for(uint j = 0u; j < rayTraceBiSteps; ++j){
					if(getDepthTex(pos.xy) >= 0.99999) return vec3(0.0); // sky

					refineDir *= 0.5;
					pos += (depth < pos.z) ? -refineDir : refineDir;
					depth = textureLod(depthtex0, pos.xy, 0).x;
				}
			#else
				if(getDepthTex(pos.xy) >= 0.99999) return vec3(0.0);
			#endif

			return vec3(pos.xy, 1.0);
		}
	}

	return vec3(0.0);
}
