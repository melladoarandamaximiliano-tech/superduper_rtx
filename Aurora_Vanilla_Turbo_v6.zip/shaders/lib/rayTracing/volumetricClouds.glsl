const uint VOLUMETRIC_CLOUD_STEPS_U = uint(VOLUMETRIC_CLOUD_STEPS);

const float volumetricCenterDepth = VOLUMETRIC_CLOUD_DEPTH * 0.5;
const float volumetricCloudHeight = 195.0 + volumetricCenterDepth;

// Optimized volumetric clouds - same visual result, less ALU and better early exits
vec2 volumetricClouds(in vec3 nFeetPlayerPos, in vec3 cameraPos, in float feetPlayerDist, in float dither, in bool isSky){
    // Cap distance
    float cloudFar = isSky ? volumetricCloudFar : min(volumetricCloudFar, feetPlayerDist);
    float invCloudFarSqrd = 1.0 / squared(volumetricCloudFar);

    // Vertical bounding box
    float lowerBoundDist = (-VOLUMETRIC_CLOUD_DEPTH - cameraPos.y) / nFeetPlayerPos.y;
    float higherBoundDist = -cameraPos.y / nFeetPlayerPos.y;

    float nearestPlane = max(min(lowerBoundDist, higherBoundDist), 0.0);
    float furthestPlane = min(cloudFar, max(lowerBoundDist, higherBoundDist));

    // Outside volume → early out
    if(furthestPlane <= nearestPlane) return vec2(0.0);

    float distInsideCloud = furthestPlane - nearestPlane;

    // Dynamic step count (capped), same visual density
    uint steps = min(uint(distInsideCloud * 0.5 + 0.5), VOLUMETRIC_CLOUD_STEPS_U);
    steps = max(steps, 1u);
    float stepsInv = 1.0 / float(steps);

    vec3 stepVec = nFeetPlayerPos * (distInsideCloud * stepsInv);
    vec3 pos = cameraPos + nFeetPlayerPos * nearestPlane + stepVec * dither;

    vec2 clouds = vec2(0.0);

    // Unrolled-friendly loop with early exit when both layers saturated
    for(uint i = 0u; i < steps; ++i){
        float cloudFog = 1.0 - lengthSquared(pos - cameraPos) * invCloudFarSqrd;

        // Faster fetch + mask
        vec2 cloudData = texelFetch(colortex0, ivec2(pos.xz * 0.0625) & 255, 0).xy;

        float h = -pos.y * cloudFog;
        if(cloudData.x > 0.5) clouds.x = max(clouds.x, h);
        if(cloudData.y > 0.5) clouds.y = max(clouds.y, h);

        // Early exit if both layers already have strong contribution
        if(clouds.x > 0.95 && clouds.y > 0.95) break;

        pos += stepVec;
    }

    return clouds;
}
