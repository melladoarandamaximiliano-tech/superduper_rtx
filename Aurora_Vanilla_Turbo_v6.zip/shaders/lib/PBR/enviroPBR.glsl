// Environment PBR calculation - enhanced for visible rain puddles
void enviroPBR(inout dataPBR material, in vec3 normal){
    if(normal.y < 0.01) return; // Only upward-facing surfaces

    float skyLightDelta = lmCoord.y - 0.75;

    if(skyLightDelta < 0.0) return;

    // Stronger rain factor for clear puddles
    float rainMatFact = (1.0 - material.porosity) * skyLightDelta * isPrecipitationRain * normal.y * 6.5;

    // Noise for puddle shape (more coverage and variation)
    vec2 noiseUV = vertexWorldPos.xz * 0.0015;
    float puddleNoise = sumOf(textureLod(noisetex, noiseUV, 0).xy);
    rainMatFact *= saturate(puddleNoise - 0.35); // Lower threshold = more/bigger puddles

    // Strong wet look
    material.normal = mix(material.normal, normal, rainMatFact * 0.85);
    material.metallic = max(0.04 * rainMatFact, material.metallic);
    material.smoothness = mix(material.smoothness, 0.97, rainMatFact); // Near-mirror when wet
    material.albedo.rgb *= 1.0 - rainMatFact * 0.55; // Darker wet surface
}
