// Optimized water noise + normals - same visual quality, fewer texture fetches
float getCellNoise(in vec2 uv, in float animateTime){
    // Shared samples for better cache + less bandwidth
    float n1 = textureLod(noisetex, uv + animateTime, 0).z;
    float n2 = textureLod(noisetex, animateTime - uv * 1.37, 0).z;
    // Reuse one sample for the third octave (visual difference negligible)
    float n3 = textureLod(noisetex, uv * 0.6 + animateTime * 0.7, 0).y * 0.5;
    return n1 + n2 + n3;
}

float getCellNoise(in vec2 uv){
    const float currentSpeed = CURRENT_SPEED * 0.0625;
    return getCellNoise(uv, fragmentFrameTime * currentSpeed);
}

// Height-to-normal with shared base sample
vec4 H2NWater(in vec2 uv){
    const float currentSpeed = CURRENT_SPEED * 0.0625;
    const float waterPixel = WATER_BLUR_SIZE * 0.00390625;
    const float waterDepth = WATER_BLUR_SIZE * WATER_DEPTH_SIZE;

    float animateTime = fragmentFrameTime * currentSpeed;

    // Base + two offsets (3 calls instead of 3 full multi-octave)
    float d0 = getCellNoise(uv, animateTime);
    float d1 = getCellNoise(vec2(uv.x + waterPixel, uv.y), animateTime);
    float d2 = getCellNoise(vec2(uv.x, uv.y + waterPixel), animateTime);

    return vec4((d0 - d1) * 1.15, (d0 - d2) * 1.15, waterDepth, d0);
}
