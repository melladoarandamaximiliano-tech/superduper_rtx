const float oneMinusShoulder = 1.0 - SHOULDER_STRENGTH;

const float shoulderFactor = oneMinusShoulder * 3.0;
const float shoulderWhitePointFactor = oneMinusShoulder / (WHITE_POINT * WHITE_POINT);

// Luminance function
float getLuminance(in vec3 col){
	return dot(col, vec3(0.2126, 0.7152, 0.0722));
}

// Saturation function
vec3 saturation(in vec3 col, in float a){
	float luma = getLuminance(col);
	return (col - luma) * a + luma;
}

// Contrast function
vec3 contrast(in vec3 col, in float a){
	return (col - 0.5) * a + 0.5;
}

// Improved modified Reinhard extended with better shoulder and highlight preservation
// Tuned for richer midtones and softer, more cinematic highlights (Aurora Ultra)
vec3 modifiedReinhardExtended(in vec3 color){
	// Pre-exposure scale for better dynamic range utilization
	color *= 1.15;

	float sumCol = sumOf(color);
	float maxCol = maxOf(color);

	// Adaptive shoulder that preserves more detail in bright areas
	float adaptiveShoulder = mix(shoulderFactor, shoulderFactor * 0.75, saturate(maxCol * 0.35));
	float rainHardFactor = (3.0 + sumCol * shoulderWhitePointFactor) / (adaptiveShoulder + sumCol);

	vec3 tonemapped = color * rainHardFactor;

	// Soft highlight compression to avoid clipping while keeping energy
	float highlightMask = saturate((maxCol - 0.85) * 2.5);
	tonemapped = mix(tonemapped, color / (1.0 + color * 0.65), highlightMask * 0.35);

	return tonemapped;
}

// Alternative Jodie-style for reference / future option
vec3 modifiedReinhardJodieExtended(in vec3 color){
	float sumCol = sumOf(color);

	vec3 reinhardColorFactor = color * ((1.0 + color * shoulderWhitePointFactor) / (oneMinusShoulder + color));
	vec3 reinhardLumaFactor = color * ((3.0 + sumCol * shoulderWhitePointFactor) / (shoulderFactor + sumCol));

	return (reinhardColorFactor - reinhardLumaFactor) * reinhardColorFactor + reinhardLumaFactor;
}
