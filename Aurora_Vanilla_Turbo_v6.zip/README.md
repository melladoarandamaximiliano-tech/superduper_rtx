# Aurora Vanilla RTX - Turbo (v6)

Version ultra-optimizada de "Aurora Vanilla RTX Ultra (Max Optimized v3)",
pensada para GPUs integradas (por ejemplo Ryzen con graficos Radeon).

> Edicion no oficial. No afiliada a Eldeston / FlameRender Studios.

## Que se apago o bajo por defecto (perfil MEDIUM)

| Efecto                         | v3            | v4 Turbo           |
|--------------------------------|---------------|--------------------|
| Anti-aliasing                  | TAA           | **FXAA** (sin TAA) |
| Outlines (contornos)           | Dungeons      | **Off**            |
| SSAO                           | On            | **Off**            |
| Luz volumetrica                | On            | **Off**            |
| Nubes                          | Volumetricas  | **Vanilla (baratas)** |
| Distancia de sombras           | 128 bloques   | **48 bloques**     |
| Sombras de color               | On            | **Off**            |
| Reflejos (SSR)                 | 16 pasos      | **12 pasos**, 1 refinado |
| Reflejos rugosos               | On            | **Off**            |
| Lens flare                     | On            | **Off**            |
| Normales generadas             | On            | **Off**            |
| PBR de entorno / subsuperficie | On            | **Off**            |

Se mantienen: sombras, bloom, reflejos del agua, espuma, animacion de plantas y agua.

## Perfiles
- **POTATO**: sin sombras, sin PBR. Maximo rendimiento.
- **LOW**: sombras 512 a 32 bloques.
- **MEDIUM** (por defecto): el equilibrio optimizado.
- **HIGH**: TAA, SSAO, reflejos rugosos y sombras de color.
- **ULTRA**: todo lo anterior + luz volumetrica y nubes en 3D.

## Instalacion
Iris recomendado. Pon el `.zip` en `shaderpacks` y elige **MEDIUM** (o LOW si quieres mas FPS).

## Creditos y licencia
- Base: **Super Duper Vanilla** por Eldeston / FlameRender Studios.
- Se incluye la licencia original (archivo LICENSE). Esta version es para uso personal.
  Si la compartes, debes mantener la licencia, los creditos al autor original y no usar
  "Super Duper Vanilla" en el nombre.

## Novedades v5: mucho mas rapido en calidad maxima (ULTRA)

Optimizaciones de codigo (se notan en todos los perfiles):
- **Pasos vacios apagados de verdad**: antes, aunque desactivaras movimiento, DOF, bloom,
  TAA o SSAO, el shader seguia copiando la imagen completa en cada paso. Ahora esos pasos
  no se ejecutan, lo que ahorra mucho ancho de banda en graficas integradas.
- **Reflejos (SSR)**: se salta el calculo cuando el reflejo seria invisible
  (superficies no metalicas vistas de frente, menos del 2 %).
- **SSAO**: solo se calcula cerca de la camara (hasta 48 bloques).
- **Nubes del cielo**: recorrido de arriba abajo con salida temprana.

Perfil ULTRA reajustado:
- Sombras 1024 a 64 bloques (misma densidad que antes con 1536 a 96, pero 2 veces menos trabajo).
- Reflejos 16 pasos, nubes 3D con 12 pasos.

## Novedades v6
- **Brillo especular**: la parte mas pesada (el calculo de luz de area del sol) ya no se
  ejecuta en los bloques sin brillo, que son la gran mayoria. El resultado es identico.
- **Luz volumetrica**: se salta el calculo de sombras cuando su aporte seria invisible
  (pixeles cercanos o niebla muy fina).
