#define VOLUMETRIC_LIGHT_STEPS 7u

const float volumetricStepsInverse = 1.0 / float(VOLUMETRIC_LIGHT_STEPS);

// Optimized VL - identical visual, less work per step
vec3 getVolumetricLight(in vec3 nFeetPlayerPos, in float feetPlayerDist, in float fogFactor, in float borderFog, in float dither, in bool isSky){
	float totalFogDensity = FOG_TOTAL_DENSITY;

	#ifdef FORCE_DISABLE_WEATHER
		if(isEyeInWater != 0) totalFogDensity *= TAU;
	#else
		totalFogDensity *= isEyeInWater == 0 ? (rainStrength * PI + 1.0) : TAU;
	#endif

	float heightFade = 1.0;

	// Height fade (same math)
	if(isEyeInWater == 0 && nFeetPlayerPos.y > 0.0){
		heightFade = squared(squared(1.0 - squared(nFeetPlayerPos.y)));
		if(isSky) heightFade *= heightFade;

		#ifndef WORLD_CUSTOM_SKYLIGHT
			#ifndef FORCE_DISABLE_WEATHER
				heightFade += (1.0 - heightFade) * max(1.0 - eyeBrightFact, rainStrength * 0.5);
			#else
				heightFade += (1.0 - heightFade) * (1.0 - eyeBrightFact);
			#endif
		#endif
	}

	float volumetricFogDensity = 1.0 - exp2(-feetPlayerDist * totalFogDensity);
	volumetricFogDensity = mix(fogFactor, volumetricFogDensity, VOLUMETRIC_LIGHTING_STRENGTH);

	#ifdef BORDER_FOG
		volumetricFogDensity = mix(1.0, volumetricFogDensity, borderFog);
	#endif

	#if defined VOLUMETRIC_LIGHTING && defined SHADOW_MAPPING
		// Precompute shadow-space direction once
		vec3 shadowDir = vec3(shadowProjection[0].x, shadowProjection[1].y, shadowProjection[2].z) * (mat3(shadowModelView) * nFeetPlayerPos);
		float maxDist = min(min(borderFar, shadowDistance), feetPlayerDist);
		vec3 stepVec = shadowDir * (maxDist * volumetricStepsInverse);

		// Start position with dither
		vec3 pos = vec3(shadowProjection[0].x, shadowProjection[1].y, shadowProjection[2].z) * shadowModelView[3].xyz + stepVec * dither;
		pos.z += shadowProjection[3].z;

		vec3 volumeData = vec3(0.0);

		// Fixed 7-step loop (easy for compiler to unroll)
		for(uint i = 0u; i < VOLUMETRIC_LIGHT_STEPS; ++i){
			// Distort + sample (same formula)
			float distort = length(pos.xy) * 2.0 + 0.2;
			volumeData += getShdCol(vec3(pos.xy / distort, pos.z * 0.1) + 0.5);
			pos += stepVec;
		}

		float strength = min(1.0, VOLUMETRIC_LIGHTING_STRENGTH * (1.0 + float(isEyeInWater)));
		return volumeData * lightCol * (strength * squared(heightFade) * volumetricFogDensity * volumetricStepsInverse);
	#else
		if(isEyeInWater == 1) return lightCol * toLinear(fogColor) * (min(1.0, VOLUMETRIC_LIGHTING_STRENGTH * 2.0) * volumetricFogDensity);
		#ifdef WORLD_CUSTOM_SKYLIGHT
			else return lightCol * (volumetricFogDensity * VOLUMETRIC_LIGHTING_STRENGTH);
		#else
			else return lightCol * (squared(eyeBrightFact) * volumetricFogDensity * VOLUMETRIC_LIGHTING_STRENGTH);
		#endif
	#endif
}
