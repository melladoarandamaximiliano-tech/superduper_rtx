// Optimized SSAO - identical visual result, fewer ops
float getSSAO(in vec3 screenPos, in vec3 viewNormal){
    #if ANTI_ALIASING >= 2
        vec3 dither = fract(getRng3(ivec2(gl_FragCoord.xy) & 255) + frameFract);
    #else
        vec3 dither = getRng3(ivec2(gl_FragCoord.xy) & 255);
    #endif

    float occlusion = 0.25;

    // Swizzle dither once
    vec3 baseDither = dither * 0.5 - 0.25;
    vec3 offsets[4] = vec3[4](
        baseDither.xyz,
        baseDither.zxy,
        baseDither.yzx,
        fract(dither.zyx + GOLDEN_RATIO) * 0.5 - 0.25
    );

    float depthOrigin = near / (1.0 - screenPos.z);
    vec3 basePos = getViewPos(gbufferProjectionInverse, screenPos) + viewNormal * 0.5;

    // 4 samples, unrolled-friendly
    for(uint i = 0u; i < 4u; ++i){
        vec3 samplePos = getScreenPos(gbufferProjection, basePos + offsets[i]);
        float sampleDepth = textureLod(depthtex0, samplePos.xy, 0).x;

        if(samplePos.z > sampleDepth){
            float linearSample = near / (1.0 - sampleDepth);
            occlusion -= 0.0625 / max(depthOrigin - linearSample, 1.0);
        }
    }

    return occlusion;
}
