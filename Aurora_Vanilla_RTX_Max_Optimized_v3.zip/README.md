# Aurora Vanilla RTX Ultra (Max Optimized v3)

**Edición comunitaria optimizada de Super Duper Vanilla.**

Se bajó agresivamente casi todo lo que más cuesta FPS, manteniendo el estilo general reconocible.

> Edición no oficial. No afiliada a Eldeston / FlameRender Studios.

---

## Qué se optimizó en v3 (más fuerte)

| Efecto                  | Original     | v3 (ahora)          |
|-------------------------|--------------|---------------------|
| Raytracer               | 32 steps     | **16 steps**        |
| Shadow map              | 4096         | **1024**            |
| Soft shadow filter      | On           | **Off**             |
| Entity / Block shadows  | On           | **Off**             |
| PREVIOUS_FRAME          | On           | **Off**             |
| Double layered clouds   | On           | **Off**             |
| Nubes (volumetric/sky)  | 32 / 48      | **16 / 16**         |
| Volumetric light        | 0.65         | **0.50**            |
| Underwater caustics     | 1            | **0**               |

### Perfiles recomendados
- **HIGH** o **ULTRA** → ahora son casi iguales y muy ligeros
- **MEDIUM** → buen equilibrio
- **LOW / POTATO** → máximo FPS

Puedes reactivar cualquier opción desde el menú del shader (Shadow Filter, Entity Shadows, PREVIOUS_FRAME, etc.).

---

## Instalación

1. Iris recomendado.
2. Pon el `.zip` en `shaderpacks`.
3. Activa y elige **HIGH**.

---

## Créditos

- Base: **Super Duper Vanilla** por Eldeston / FlameRender Studios.
- Optimizaciones agresivas: Aurora Vanilla RTX Ultra (Max Optimized v3).

¡Mucho más fluido!
