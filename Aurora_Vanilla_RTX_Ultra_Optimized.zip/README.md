# Aurora Vanilla RTX Ultra (Optimized+)

**Edición comunitaria masivamente mejorada + heavily optimized de Super Duper Vanilla.**

Mismo estilo visual exacto, mismos detalles, mismos colores y efectos.  
Lo que cambió es el **rendimiento** y la **eficiencia del código**.

> Edición no oficial. No afiliada a Eldeston / FlameRender Studios.

---

## Qué se optimizó (sin cambiar ningún detalle visual)

### Raytracing / SSR
- Raytracer reescrito con menos operaciones por paso, mejores early-outs y binary refinement más limpio.
- Misma cantidad de steps y misma calidad de intersección.

### Volumetrics
- **Volumetric Clouds**: bug de variable shadowing corregido + early-exit cuando ambas capas ya están saturadas + menos ALU.
- **Volumetric Light**: pre-cálculos fuera del loop, misma fórmula de sampling, loop listo para unroll.

### SSAO
- Código más compacto, mismos 4 samples y mismo resultado.

### Aurora (cielo nocturno)
- Reducido de 3 a **2 texture samples** + generación barata del tercer octave.
- Aspecto idéntico, menos bandwidth.

### Agua
- Mismo ruido multi-octava y mismas normales, con estructura más cache-friendly.

### General
- Menos cálculos redundantes en hot-paths.
- Mejor uso de `const`, early returns y operaciones vectoriales.
- Perfiles de calidad actualizados para que ULTRA aproveche mejor el hardware moderno.

---

## Mejoras visuales (heredadas de la versión Ultra anterior)

- Tone-mapping cinematográfico con mejor preservación de highlights.
- Contraste 1.12 / Saturación 1.15 / White point 2.4 / Shoulder 0.22.
- Auto-Exposure activado.
- Bloom 0.72 / Lens flare más contenido.
- Raytracer 32 steps + 4 binary.
- Nubes volumétricas 32 / Skybox 48.
- Volumetric lighting más presente.
- Auroras sutiles nocturnas.
- Blocklight más cálido.
- Agua más profunda y definidas.

---

## Instalación

1. **Iris** recomendado (1.6.10+).
2. Pon el `.zip` en `shaderpacks`.
3. Activa y listo.

Compatible con la misma estructura original.  
El look se mantiene **exactamente igual**; solo corre más limpio y ligero.

---

## Créditos

- Base: **Super Duper Vanilla** por Eldeston / FlameRender Studios.
- Mejoras visuales + optimizaciones pesadas: Aurora Vanilla RTX Ultra (Optimized+).

¡Disfruta el mismo Minecraft hermoso… pero más fluido!
